package com.user.service;

import com.user.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceimpl implements UserService{

//fake user list
    List<User> list=List.of(new User(121314L,"swati Nagode","9075670117"),
        new User(121315L,"sopan Nagode","9075690117"),
        new User(121316L,"sachin Nagode","9075900117"));
    @Override
    public User getUser(Long id) {
        return list.stream().filter(user -> user.getUserId().equals(id)).findAny().orElse(null);
    }
}
