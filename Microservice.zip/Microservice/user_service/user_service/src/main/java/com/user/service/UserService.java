package com.user.service;

import com.user.entity.User;

public interface UserService {
    User getUser(Long id);
}
