package com.contact.service;


import com.contact.entity.Contact;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactServiceimpl implements ContactService{

    List<Contact> list=  List.of(new Contact(1L,"zagaregb@gmail.com","ganesh Zagare",121314L),
                                 new Contact(2L,"kawya@gmail.com","kawya",121314L),
                                 new Contact(3L,"zagaregb@gmail.com","ganesh Zagare",121315L),
                                 new Contact(4L,"zagaregb@gmail.com","ganesh Zagare",121316L)
                );

    @Override
    public List<Contact> getContactsOfUser(Long userId) {
        return list.stream().filter(contact -> contact.getUserId().equals(userId)).collect(Collectors.toList());
    }

}
