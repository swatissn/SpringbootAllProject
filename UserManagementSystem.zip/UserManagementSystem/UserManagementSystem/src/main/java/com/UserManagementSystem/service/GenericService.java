package com.UserManagementSystem.service;

import java.util.List;

public interface GenericService<T,ID> {
    T findById(ID id);
    T save(T t);
    T Update(T t);
    T delete(ID id);

    List<T> findAll();
    List<T> saveAll(List<T> t);
    List<T> updateAll(List<T> t);
    int deleteAll(List<Long> ids);
}
