package com.UserManagementSystem.service;

import com.UserManagementSystem.modal.User;
import com.UserManagementSystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements GenericService<User, Long> {
    @Autowired
    UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public User findById(Long id) {
        return repository.findById(id).get();
    }

    @Override
    public User save(User user) {
        return repository.save(user);
    }

    @Override
    public User Update(User user) {
        return repository.save(user);
    }

    @Override
    public User delete(Long id) {
        User one= repository.getOne(id);
        if(one!=null){
            repository.findById(id);
            return  one;
        }
        return new User();
    }

    @Override
    public List<User> findAll() {
        return repository.findAll();
    }

    @Override
    public List<User> saveAll(List<User> users) {
        return repository.saveAll(users);
    }

    @Override
    public List<User> updateAll(List<User> users) {
        return repository.saveAll(users);
    }

    @Override
    public int deleteAll(List<Long> ids) {
        return repository.deleteByIds(ids);
    }
}
