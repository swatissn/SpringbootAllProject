package com.UserManagementSystem.repository;

import com.UserManagementSystem.modal.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.NamedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
@NamedQuery(name="deleteByIds ",query="delete from UserDemo where id in {}")
public interface UserRepository extends JpaRepository<User,Long> {

    @Transactional
    @Modifying
    @Query("delete from UserDemo u where u.id in :ids")
    int deleteByIds(List<Long>ids);
}
