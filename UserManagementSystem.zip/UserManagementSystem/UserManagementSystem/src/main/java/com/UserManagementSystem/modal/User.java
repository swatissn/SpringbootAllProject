package com.UserManagementSystem.modal;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Setter
@Getter
@ToString
@Entity(name="UserDemo")
public class User {
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private String emailid;
    
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	private double salary;

    public User() {
    }

    public User(Long id, String name, String emailid, double salary) {
        this.id = id;
        this.name = name;
        this.emailid = emailid;
        this.salary = salary;
    }

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", emailid=" + emailid + ", salary=" + salary + ", getId()="
				+ getId() + ", getName()=" + getName() + ", getEmailid()=" + getEmailid() + ", getSalary()="
				+ getSalary() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
    
    
}
