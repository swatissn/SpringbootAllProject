package com.UserManagementSystem.controller;


import com.UserManagementSystem.modal.User;
import com.UserManagementSystem.service.GenericService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.sql.Driver;
import java.util.List;

@RestController
@RequestMapping(value="/user",produces = {MediaType.APPLICATION_JSON_VALUE},consumes = {MediaType.APPLICATION_JSON_VALUE})
public class UserController {

    @Autowired
    GenericService<User,Long> service;

    public UserController(GenericService<User, Long> service) {
        this.service = service;
    }
    
    //http://localhost:8082/user/id
    @GetMapping("/id/{id}")
    public User getById(@PathVariable("id") Long id)
    {
     return  service.findById(id);
    }
    
    //http://localhost:8082/user
    @GetMapping
    public List<User>  getAll(){
        return service.findAll();
    }
    
    //http://localhost:8082/user
    @PostMapping
    public List<User> addAllUser(@RequestBody List<User> user){
        return service.saveAll(user);
    }
    
    //http://localhost:8082/user
    @PutMapping
    public List<User> updateAll(@RequestBody List<User> user){
        return  service.updateAll(user);
    }
    
    //http://localhost:8082/user?ids=61
    @DeleteMapping
    int deleteAllUser(@RequestParam("ids") List<Long> ids){
        return service.deleteAll(ids);

    }


}
