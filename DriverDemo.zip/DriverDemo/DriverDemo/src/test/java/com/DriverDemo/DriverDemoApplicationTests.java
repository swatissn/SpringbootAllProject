package com.DriverDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
