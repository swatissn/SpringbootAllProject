package com.DriverDemo.service;

import com.DriverDemo.modal.Driver;
import com.DriverDemo.repository.DriverRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DriverService implements GenericService<Driver,Long>{

    @Autowired
    DriverRepository driverRepository;

    public DriverService(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    @Override
    public Driver findById(Long id) {
        return driverRepository.findById(id).get();
    }

    @Override
    public List<Driver> findALL() {
        return driverRepository.findAll();
    }

    @Override
    public List<Driver> saveAll(List<Driver> drivers) {
        return driverRepository.saveAll(drivers);
    }

    @Override
    public List<Driver> updateAll(List<Driver> drivers) {
        return driverRepository.saveAll(drivers);
    }

    @Override
    public Driver save(Driver driver) {
        return driverRepository.save(driver);
    }

    @Override
    public Driver update(Driver driver) {
        return driverRepository.save(driver);
    }

    @Override
    public Driver delete(Long id) {
        Driver one=driverRepository.getOne(id);
        if(one!=null)
        {
            driverRepository.deleteById(id);
            return one;
        }
      return new Driver();
    }
}
