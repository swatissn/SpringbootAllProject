package com.DriverDemo.service;

import java.util.List;

public interface GenericService<T,ID> {
    T findById(ID id);

    T save(T t);
    T update(T t);
    T delete(ID id);

    List<T> findALL();
    List<T> saveAll(List<T> t);
    List<T> updateAll(List<T> t);
}
