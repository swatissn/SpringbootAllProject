package com.DriverDemo.modal;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Getter
@Setter
@ToString
@Entity(name="driver")
public class Driver
{
    @Id
    @GeneratedValue
    private Long id;

    @Column(name="Name")
    private  String name;
    private  String  address;
    private  String state;

    public Driver() {
    }

    public Driver(long id, String name, String address, String state) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.state = state;
    }


}
