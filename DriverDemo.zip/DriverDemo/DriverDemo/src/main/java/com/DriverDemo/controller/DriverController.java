package com.DriverDemo.controller;

import com.DriverDemo.modal.Driver;
import com.DriverDemo.service.GenericService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value="/driver",produces = {MediaType.APPLICATION_JSON_VALUE},consumes = {MediaType.APPLICATION_JSON_VALUE})
public class DriverController {

    @Autowired
    GenericService<Driver,Long> service;

    public DriverController(GenericService<Driver, Long> service) {
        this.service = service;
    }
    @GetMapping
    List<Driver> getAll()
    {
        return service.findALL();
    }
    @GetMapping("/id/{id}")
    Driver getById(@PathVariable("id") Long id){
        return service.findById(id);
    }
    /*@PostMapping
    Driver addDriver(@RequestBody Driver driver){
        return service.save(driver);
    }*/
    @PutMapping
    Driver updateDriver(@RequestBody Driver driver)
    {
        return service.update(driver);
    }
    @DeleteMapping("/id/{id}")
    Driver deleteDriver(@PathVariable("id") Long id)
    {
      return service.delete(id);
    }
    @PostMapping
    List<Driver> addAll(@RequestBody List<Driver> drivers){
        return service.saveAll(drivers);
    }

}
