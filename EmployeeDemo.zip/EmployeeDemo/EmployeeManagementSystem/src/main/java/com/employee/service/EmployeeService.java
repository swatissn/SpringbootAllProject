package com.employee.service;

import java.util.List;

import com.employee.model.Employee;

public interface EmployeeService {
    List<Employee> getAllEmployees();

    Employee saveEmployee(Employee employee);

    Employee getByEmployeeId(Long id);

    Employee updateEmployee(Employee employee);

    void deleteEmployee(Long id);




}
