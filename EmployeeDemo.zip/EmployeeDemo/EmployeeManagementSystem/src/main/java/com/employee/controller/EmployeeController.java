package com.employee.controller;


import com.employee.model.Employee;
import com.employee.service.EmployeeService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class EmployeeController {

    EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    //get list of Employee API
    @GetMapping("/employees")
    public String getAllEmployees(Model model) {
        model.addAttribute("employees", employeeService.getAllEmployees());
        return "employees";
    }

    //create employee
    @GetMapping("/employees/new")
    public String showNewEmployeeForm(Model model) {
        //create model object to bind data
        Employee employee = new Employee();
        model.addAttribute("employee", employee);
        return "create_employee";
    }

    //save employee
    @PostMapping("/employees")
    public String saveEmployee(@ModelAttribute("employee") Employee employee) {
        employeeService.saveEmployee(employee);
        return "redirect:/employees";
    }

    //get by employee id
    @GetMapping("/employees/edit/{id}")
    public String getByEmployeeId(@PathVariable("id") Long id, Model model) {
        model.addAttribute("employee", employeeService.getByEmployeeId(id));
        return "edit_employee";
    }


    //update Employee
    @PostMapping("/employees/{id}")
    public String updateEmployee(@PathVariable("id") Long id, @ModelAttribute("employee") Employee employee, Model model) {

        Employee existingEmployee = new Employee();

        existingEmployee.setId(employee.getId());
        existingEmployee.setFirstName(employee.getFirstName());
        existingEmployee.setLastName(employee.getLastName());
        existingEmployee.setEmail(employee.getEmail());

        employeeService.updateEmployee(existingEmployee);

       return "redirect:/employees";

    }

    //delete by id
    @GetMapping("/employees/{id}")
    public String deleteEmployee(@PathVariable("id") Long id){
        employeeService.deleteEmployee(id);
        return "redirect:/employees";
    }
}
