package com.learn.springbootsecuritylearn.repository;

public interface Userrepository  {

}
