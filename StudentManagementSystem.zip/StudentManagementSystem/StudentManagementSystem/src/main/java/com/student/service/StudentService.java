package com.student.service;

import com.student.modal.Student;
import org.yaml.snakeyaml.events.Event;

import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();

    Student saveStudents(Student student);

    Student updateStudents(Student student);

    Student getStudentById(Long id);

    void deleteStudent(Long id);
}
