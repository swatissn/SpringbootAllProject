package com.student.controller;

import com.student.modal.Student;
import com.student.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class StudentController {

    @Autowired
    StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }


    //handler method to handle list students and return model and views
    @GetMapping("/students")
    public String getAllStudents(Model model) {
        model.addAttribute("students", studentService.getAllStudents());
        return "students";
    }

    //create student
    @GetMapping("/students/new")
    public String createStudentsForm(Model model) {
        Student student = new Student();
        model.addAttribute("student", student);
        return "create_student";
    }

    //save student
    @PostMapping("/students")
    public String saveStudents(@ModelAttribute("student") Student student) {
        studentService.saveStudents(student);
        return "redirect:/students";
    }

    //get student by id
    @GetMapping("/students/edit/{id}")
    public String editStudentForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("student", studentService.getStudentById(id));
        return "edit_student";
    }

    //update student
    @PostMapping("/students/{id}")
    public String updateStudents(@PathVariable("id") Long id,
                                 @ModelAttribute("student") Student student, Model model) {
        //get student by id from database
        Student existingStudent = studentService.getStudentById(id);

        existingStudent.setId(student.getId());
        existingStudent.setFirstName(student.getFirstName());
        existingStudent.setLastName(student.getLastName());
        existingStudent.setEmail(student.getEmail());

        //after that update student
        studentService.updateStudents(existingStudent);

        return "redirect:/students";

    }

    //delete student from database
    @GetMapping("/students/{id}")
    public String deleteStudent(@PathVariable("id") Long id) {
        studentService.deleteStudent(id);
        return "redirect:/students";
    }

}
